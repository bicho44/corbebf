<?php

namespace App\Filament\Resources\SucursalesResource\Pages;

use App\Filament\Resources\SucursalesResource;
use Filament\Resources\Pages\ListRecords;

class ListSucursales extends ListRecords
{
    protected static string $resource = SucursalesResource::class;

}
