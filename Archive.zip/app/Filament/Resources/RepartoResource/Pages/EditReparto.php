<?php

namespace App\Filament\Resources\RepartoResource\Pages;

use App\Filament\Resources\RepartoResource;
use Filament\Resources\Pages\EditRecord;

class EditReparto extends EditRecord
{
    protected static string $resource = RepartoResource::class;
}
