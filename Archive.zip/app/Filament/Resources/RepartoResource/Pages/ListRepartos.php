<?php

namespace App\Filament\Resources\RepartoResource\Pages;

use App\Filament\Resources\RepartoResource;
use Filament\Resources\Pages\ListRecords;

class ListRepartos extends ListRecords
{
    protected static string $resource = RepartoResource::class;
}
