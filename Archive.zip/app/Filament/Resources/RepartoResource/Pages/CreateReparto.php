<?php

namespace App\Filament\Resources\RepartoResource\Pages;

use App\Filament\Resources\RepartoResource;
use Filament\Resources\Pages\CreateRecord;

class CreateReparto extends CreateRecord
{
    protected static string $resource = RepartoResource::class;
}
