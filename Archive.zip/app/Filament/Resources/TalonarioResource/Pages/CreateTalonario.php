<?php

namespace App\Filament\Resources\TalonarioResource\Pages;

use App\Filament\Resources\TalonarioResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTalonario extends CreateRecord
{
    protected static string $resource = TalonarioResource::class;
}
