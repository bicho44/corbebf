
<?php /**PATH /Users/bicho44/Sites/corbebf/vendor/filament/filament/src/../resources/views/components/layouts/app/sidebar/footer.blade.php ENDPATH**/ ?>